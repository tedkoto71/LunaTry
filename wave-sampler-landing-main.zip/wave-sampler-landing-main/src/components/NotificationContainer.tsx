
import React from 'react';
import { NotificationPopup } from './NotificationPopup';
import { useNotifications } from '@/hooks/useNotifications';

export const NotificationContainer: React.FC = () => {
  const { currentNotification, isVisible } = useNotifications();

  if (!currentNotification) return null;

  return (
    <div className="fixed bottom-4 left-4 z-50 pointer-events-none">
      <NotificationPopup
        notification={currentNotification}
        isVisible={isVisible}
      />
    </div>
  );
};
