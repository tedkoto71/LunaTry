
import React from 'react';
import { CheckCircle } from 'lucide-react';

interface Notification {
  id: string;
  name: string;
  location: string;
  deals: number;
  timestamp: number;
}

interface NotificationProps {
  notification: Notification;
  isVisible: boolean;
}

export const NotificationPopup: React.FC<NotificationProps> = ({
  notification,
  isVisible
}) => {
  return (
    <div
      className={`
        notification-glow max-w-xs rounded-lg p-4 pointer-events-auto
        transition-all duration-300 ease-out transform
        ${isVisible 
          ? 'translate-x-0 opacity-100' 
          : '-translate-x-full opacity-0'
        }
      `}
    >
      <div className="flex items-start space-x-3">
        <div className="flex-shrink-0">
          <CheckCircle className="w-6 h-6 text-primary glow-text" />
        </div>
        
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-foreground">
            <span className="font-semibold glow-text">{notification.name}</span> just claimed their $750 Lululemon Gift Card!
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Just now
          </p>
        </div>
      </div>
    </div>
  );
};
