
import { useState, useEffect } from 'react';

interface Notification {
  id: string;
  name: string;
  location: string;
  deals: number;
  timestamp: number;
}

const firstNames = [
  'Sarah', 'Mike', 'Emily', 'James', 'Jessica', 'David', 'Ashley', 'Chris',
  'Amanda', 'Ryan', 'Jennifer', 'Matt', 'Lisa', 'Kevin', 'Rachel', 'Tyler',
  'Megan', 'Josh', 'Nicole', 'Alex', 'Samantha', 'Ben', 'Taylor', 'Daniel'
];

const locations = [
  'New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix', 'Philadelphia',
  'San Antonio', 'San Diego', 'Dallas', 'San Jose', 'Austin', 'Jacksonville',
  'Toronto', 'Vancouver', 'Montreal', 'Calgary', 'Ottawa', 'Edmonton',
  'London', 'Manchester', 'Birmingham', 'Leeds', 'Glasgow', 'Liverpool',
  'Sydney', 'Melbourne', 'Brisbane', 'Perth', 'Adelaide', 'Canberra'
];

export const useNotifications = () => {
  const [currentNotification, setCurrentNotification] = useState<Notification | null>(null);
  const [isVisible, setIsVisible] = useState(false);

  const createNotification = (): Notification => {
    const randomName = firstNames[Math.floor(Math.random() * firstNames.length)];
    const randomLocation = locations[Math.floor(Math.random() * locations.length)];
    
    return {
      id: Math.random().toString(36).substr(2, 9),
      name: randomName,
      location: randomLocation,
      deals: 0, // Not used in new format
      timestamp: Date.now()
    };
  };

  useEffect(() => {
    const showNotification = () => {
      const notification = createNotification();
      setCurrentNotification(notification);
      setIsVisible(true);
      
      // Hide after 5 seconds
      setTimeout(() => {
        setIsVisible(false);
        setTimeout(() => {
          setCurrentNotification(null);
        }, 300); // Wait for fade out animation
      }, 5000);
    };

    // First notification after 3 seconds
    const initialTimeout = setTimeout(() => {
      showNotification();
    }, 3000);

    // Then show notifications every 13 seconds (5s visible + 8s hidden)
    const interval = setInterval(() => {
      showNotification();
    }, 13000);

    return () => {
      clearTimeout(initialTimeout);
      clearInterval(interval);
    };
  }, []);

  return { currentNotification, isVisible };
};
