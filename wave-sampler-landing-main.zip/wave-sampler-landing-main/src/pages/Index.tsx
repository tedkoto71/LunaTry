import { Button } from "@/components/ui/button";
import { NotificationContainer } from "@/components/NotificationContainer";
import { Sparkles, Gift, Users } from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen gradient-background relative">
      {/* Floating Particles */}
      <div className="floating-particles">
        <div className="particle"></div>
        <div className="particle"></div>
        <div className="particle"></div>
        <div className="particle"></div>
        <div className="particle"></div>
        <div className="particle"></div>
        <div className="particle"></div>
        <div className="particle"></div>
        <div className="particle"></div>
      </div>

      {/* Notification Container */}
      <NotificationContainer />

      {/* Main Content */}
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 py-8">
        <div className="max-w-4xl w-full text-center space-y-12">
          
          {/* Hook Section */}
          <div className="space-y-6">
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-foreground glow-text leading-tight">
              Claim Your
              <span className="block text-primary glow-text">$750 Lululemon</span>
              Gift Card
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Join an exclusive community of premium activewear enthusiasts. 
              Your luxury voucher awaits.
            </p>
          </div>

          {/* CTA Button */}
          <div className="flex justify-center">
            <Button 
              className="glow-button text-lg md:text-xl font-semibold px-12 py-6 rounded-full transition-all duration-300 hover:scale-105"
              onClick={() => {
                window.open("https://rewarrdsgiant.com/aff_c?offer_id=1137&aff_id=42125", "_blank");
              }}
            >
              <Gift className="w-6 h-6 mr-2" />
              Claim Your $750 Gift Card
            </Button>
          </div>

          {/* Steps Section */}
          <div className="space-y-8 max-w-3xl mx-auto">
            <h2 className="text-2xl md:text-3xl font-bold text-foreground glow-text">
              How It Works
            </h2>
            
            <div className="grid md:grid-cols-3 gap-8">
              {/* Step 1 */}
              <div className="glow-border rounded-xl p-6 space-y-4 hover:scale-105 transition-all duration-300">
                <div className="flex justify-center">
                  <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center glow-border">
                    <span className="text-2xl font-bold text-primary glow-text">1</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <Sparkles className="w-8 h-8 text-primary mx-auto glow-text" />
                  <h3 className="text-lg font-semibold text-foreground">Click to Claim</h3>
                  <p className="text-sm text-muted-foreground">
                    Begin your journey to premium activewear excellence
                  </p>
                </div>
              </div>

              {/* Step 2 */}
              <div className="glow-border rounded-xl p-6 space-y-4 hover:scale-105 transition-all duration-300">
                <div className="flex justify-center">
                  <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center glow-border">
                    <span className="text-2xl font-bold text-primary glow-text">2</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <Users className="w-8 h-8 text-primary mx-auto glow-text" />
                  <h3 className="text-lg font-semibold text-foreground">Quick Setup</h3>
                  <p className="text-sm text-muted-foreground">
                    Enter your details and complete simple verification steps
                  </p>
                </div>
              </div>

              {/* Step 3 */}
              <div className="glow-border rounded-xl p-6 space-y-4 hover:scale-105 transition-all duration-300">
                <div className="flex justify-center">
                  <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center glow-border">
                    <span className="text-2xl font-bold text-primary glow-text">3</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <Gift className="w-8 h-8 text-primary mx-auto glow-text" />
                  <h3 className="text-lg font-semibold text-foreground">Enjoy Shopping</h3>
                  <p className="text-sm text-muted-foreground">
                    Receive your gift card and shop premium Lululemon gear
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Geographic Notice */}
          <div className="glow-border rounded-xl p-6 max-w-2xl mx-auto">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mx-auto glow-border">
                <span className="text-lg text-primary glow-text">!</span>
              </div>
              <h3 className="text-xl font-bold text-foreground glow-text">
                Geographic Availability
              </h3>
              <p className="text-muted-foreground">
                This exclusive opportunity is available to residents of the 
                <span className="text-primary font-semibold glow-text"> United Kingdom</span>, 
                <span className="text-primary font-semibold glow-text"> United States</span>, 
                <span className="text-primary font-semibold glow-text"> Canada</span>, and 
                <span className="text-primary font-semibold glow-text"> Australia</span>.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;